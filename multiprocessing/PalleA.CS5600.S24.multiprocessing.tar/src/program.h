
void createFolder(const char* folder_name);
char* concat(const char* s1, const char* s2);

void runProgram(char* outputFolder, char* runName, int numStrings);