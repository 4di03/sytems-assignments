
char* randomString(int length);


char** generateRandomStringsInMemory(int numStrings, int stringLength);

void generateRandomStrings(int numStrings, int stringLength, char* saveFilePath);