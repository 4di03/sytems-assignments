
#include <stdio.h>
#include <stdlib.h>



int genRand(int start, int end);


int charToInt(char digitChar);