TO run the code for question 1, do 
```make && ./pqueue```

The sample output for q1 is stored at ```q1_sample_output.txt```

To run the code for question 2, do
```make && ./q2```

The sample output for q2 is stored at ```q2_sample_output.txt```
